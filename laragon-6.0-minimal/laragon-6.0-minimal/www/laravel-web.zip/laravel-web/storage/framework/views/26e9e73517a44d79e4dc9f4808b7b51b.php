<!DOCTYPE html>
<html>
<head>
    <title>About Page</title>
</head>
<body>
    <h1>Ini adalah halaman About</h1>
    <p>Laravel membuat development lebih cepat 🚀</p>
</body>
</html><?php /**PATH C:\laragon\www\2TIB_Zakiyasri\laragon-6.0-minimal\laragon-6.0-minimal\www\laravel-web\resources\views/halaman-about.blade.php ENDPATH**/ ?>