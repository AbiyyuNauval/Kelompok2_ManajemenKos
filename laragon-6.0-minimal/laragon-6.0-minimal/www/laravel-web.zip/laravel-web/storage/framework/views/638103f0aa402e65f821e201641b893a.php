<html>
    <body>
        <h1>Selamat Datang!</h1>
        <h2>Ini halaman Detail Mahasiswa</h2>
    </body>
</html><?php /**PATH C:\laragon\www\2TIB_Zakiyasri\laragon-6.0-minimal\laragon-6.0-minimal\www\laravel-web\resources\views/halaman-mahasiswa-detail.blade.php ENDPATH**/ ?>