<html>
    <body>
        <h1>Selamat Datang!</h1>
        <h2>Ini halaman Profil Mahasiswa</h2>
    </body>
</html><?php /**PATH C:\laragon\www\2TIB_Zakiyasri\laragon-6.0-minimal\laragon-6.0-minimal\www\laravel-web\resources\views/halaman-mahasiswa-profil.blade.php ENDPATH**/ ?>