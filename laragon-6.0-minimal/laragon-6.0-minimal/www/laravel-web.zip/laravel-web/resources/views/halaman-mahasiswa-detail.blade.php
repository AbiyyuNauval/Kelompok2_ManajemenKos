<html>
    <body>
        <h1>Selamat Datang!</h1>
        <h2>Ini halaman Detail Mahasiswa</h2>
    </body>
</html>