<!DOCTYPE html>
<html>
<head>
    <title>About Page</title>
</head>
<body>
    <h1>Ini adalah halaman About</h1>
    <p>Laravel membuat development lebih cepat 🚀</p>
</body>
</html>